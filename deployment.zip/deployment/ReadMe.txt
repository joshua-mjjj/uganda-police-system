VIPPU UI

UI files for react 

 - Pull files from git

 - cd into root directory

 - run `npm install`

 - run `npm start`

 - And your good to go...
